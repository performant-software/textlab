(function() { this.JST || (this.JST = {}); this.JST["textlab/templates/common/tab-pane"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div id="',  id ,'" class="tab-pane"></div>\n');}return __p.join('');};
}).call(this);
