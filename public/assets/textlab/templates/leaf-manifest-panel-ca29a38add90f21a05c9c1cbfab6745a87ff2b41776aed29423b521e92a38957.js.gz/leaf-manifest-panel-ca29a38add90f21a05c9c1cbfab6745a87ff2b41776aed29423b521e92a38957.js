(function() { this.JST || (this.JST = {}); this.JST["textlab/templates/leaf-manifest-panel"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div id="drop-zone"><span class=\'drop-zone-message\'>',  dropZoneInstructions ,'</span></div>\n');}return __p.join('');};
}).call(this);
