
// application namespace
var TextLab = {};
